<?php
/**
 * تنظیمات رله — کلیدها را اینجا بگذارید، نه داخل relay.php
 *
 * ⚠️ این فایل حاوی کلیدهای حساس است. اگر در گیت نگه می‌دارید،
 *    حتماً آن را در .gitignore بگذارید.
 */
return [
    // ═══ اجباری ═══
    // با این دستور بسازید:  openssl rand -hex 32
    'relay_secret'      => '',

    // ═══ دروازه هوش مصنوعی ═══
    'ai_gateway_key'    => '',                            // رمزی که سایت می‌فرستد
    'openai_api_key'    => '',                            // کلید واقعی AgentRouter
    'openai_base'       => 'https://agentrouter.org/v1',
    'anthropic_base'    => 'https://agentrouter.org',

    // ═══ لینکدین ═══
    'linkedin_token'    => '',
    'linkedin_author'   => '',                            // urn:li:person:XXXX

    // ═══ اینستاگرام (بعداً پر می‌شود) ═══
    'instagram_token'   => '',
    'instagram_user_id' => '',

    // ═══ فیسبوک (اختیاری) ═══
    'fb_token'          => '',
    'fb_page_id'        => '',
];
